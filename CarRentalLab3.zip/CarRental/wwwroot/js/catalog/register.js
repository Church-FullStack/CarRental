
function Car(year, make, model, miles, category, color, mpg, price, image, isManual) {
    this.year = parseInt(year) || 0;
    this.make = make;
    this.model = model;
    this.miles = parseInt(miles) || 0;
    this.category = category;
    this.color = color;
    this.mpg = parseInt(mpg) || 0;
    this.price = parseInt(price) || 0.00;
    this.image = image;
    this.isManual = isManual;
}

function register(){
    var year = $("#txtYear").val();
    var make = $("#txtMake").val();
    var model = $("#txtModel").val();
    var miles = $("#txtMiles").val();
    var category = $("#selCategory").val();
    var color = $("#txtColor").val();
    var mpg = $("#txtMPG").val();
    var price = $("#txtPrice").val();
    var image = $("#txtImage").val();
    var isManual = $("#rdbTrans_1").is(":checked");

    var car = new Car(year, make, model, miles, category, color, mpg, price, image, isManual);
    console.log('car data', car);

    $.ajax({
        type: 'POST',
        url: '/catalog/registerCar',
        data: JSON.stringify(car),
        contentType: 'application/json',
        success: function(res){
            console.log("response:", res);
        },
        error: function(errorDetails){
            console.log("Error:", errorDetails);
        }
    });

}

function init() {
    console.log("Register page");

    $("#btnsave").click(register);
}
window.onload = init;