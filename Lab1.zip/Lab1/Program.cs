﻿using System;
using System.Collections.Generic;

namespace Lab1
{
    class Program
    {
        static void Main(string[] args)
        {
            var p = new Program();
            p.Test();
        }
        void Test() {
            Console.WriteLine("Hello World!");

            string name = "Christopher";
            int age = 28;
            Console.WriteLine(name);
            Console.WriteLine(age);

            for(int i = 0; i<10; i++) {
                Console.WriteLine(i);

                if(i==5) {
                    Console.WriteLine("its five");
                }
            }
            string message = SayHello("cool", "beans", 9000);
            Console.WriteLine(message);
            ListTest();
        }
        public string SayHello(string name, string lastName, int age){
            if(age>50){
                return "hello" + name;
            }
            
            return null;
        }
        void ListTest(){
            string[] ages = new string [999];
            List<int> listOfAges = new List<int>();
            listOfAges.Add(20);
            listOfAges.Add(10);
            listOfAges.Add(30);
            listOfAges.Add(40);
            listOfAges.Add(8);
            listOfAges.Add(90);

            var sum = 0;
            var smol = listOfAges[0];
            var big = listOfAges[0];

            for(var i = 0; i < listOfAges.Count; i++){
                var age = listOfAges[i];
                sum += age;

                if(age < smol){
                    smol = age;
                }
                if(age > smol){
                    big = age;
                }
            }
            var avg = sum / listOfAges.Count;
            System.Console.WriteLine(sum);
            System.Console.WriteLine(big);
            System.Console.WriteLine(smol);
            System.Console.WriteLine(avg);
        }
    }
}
/*1 -> the smallest number in the list
  2 -> biggest number in the list
  3 -> the sum of all the numbers
  4 -> the average  */