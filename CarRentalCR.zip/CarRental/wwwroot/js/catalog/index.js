var catalog = [];
function fetchCatalog(){

        $.ajax({
            type: "GET",
            url: '/catalog/getCatalog',
            success: function(res){
                console.log("success", res);
                catalog = res
                displayCars();
            },
            
            error: function(error){
                console.log("error", error);
            }
        });
}

function displayCars() {

    for(let i=0; i < catalog.length; i++){
        var car = catalog[i];

        var syntax =
        `
        <div class="carimg" onclick="displayModal(${i})">
        <img src="${car.image}">
        <div class="car">
        <label>${car.year} ${car.make} ${car.model} - <b>$${car.price}</b></label>
        <br>
        <label class="miles">Miles: ${car.miles}</label>
        <br>
        <button class="btn btn-secondary">Rent</button>
        </div>
        </div>`;

        $("#catalog-container").append(syntax);
    }

}

function displayModal(index) {
    var car = catalog[index];
 console.log('click', car);

 $("#popup").modal();
 $("#mdlTitle").text(`${car.year} ${car.make} ${car.model} `);
 $("#mdlbdy").html(` <img src="${car.image}"> <br>Category: ${car.category} <br> Color: ${car.color} <br> MPG: ${car.mpg} <br> Price: $${car.price}`);
 $("#mdltrans").text(trans);
 var trans = car.isManual ? "Manual" : "Automatic";
}

function init(){
    console.log("js");
    fetchCatalog();
}
window.onload = init;