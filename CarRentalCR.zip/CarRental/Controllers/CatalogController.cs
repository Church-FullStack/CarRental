using Microsoft.AspNetCore.Mvc;
using System.Linq;



namespace CarRental.Controllers{
    public class CatalogController: Controller {

        private DataContext dbContext;

        public CatalogController(DataContext context){

            this.dbContext = context;
        }


        public IActionResult Index()
        {
            return View(); //catalog page
        }

        public IActionResult Register()
        {
            return View();
        }
        
        [HttpGet]
        public IActionResult GetCatalog(){
            var list = dbContext.Cars.ToList();
            return Json(list);
            
        }
        public IActionResult GetTrucks(){
            var list = dbContext.Cars.Where(c => c.Category == "Sedan").ToList();
            return Json(list);
        }
    
        [HttpPost]
        public IActionResult RegisterCar([FromBody]Car theCar){
            System.Console.WriteLine("User is saving");

            dbContext.Cars.Add(theCar);
            dbContext.SaveChanges();

            return Json(theCar);
        }
    }
}